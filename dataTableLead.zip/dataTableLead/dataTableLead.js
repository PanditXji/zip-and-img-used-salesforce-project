import {LightningElement, wire, track, api} from 'lwc';
import {getListUi} from 'lightning/uiListApi';
import {updateRecord} from 'lightning/uiRecordApi';
import {refreshApex} from '@salesforce/apex';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';
import LEAD_OBJECT from '@salesforce/schema/Lead';
import LEAD_NAME from '@salesforce/schema/Lead.Name';
import LEAD_EMAIL from '@salesforce/schema/Lead.Email';
import LEAD_COMPANY from '@salesforce/schema/Lead.Company';
import LEAD_STATUS from '@salesforce/schema/Lead.Status';

const COLUMNS = [
  {
    label: 'Name',
    fieldName: 'Name',
    editable: true,
  },
  {
    label: 'Email',
    fieldName: 'Email',
    type: 'email',
    editable: true,
  },
  {
    label: 'Company',
    fieldName: 'Company',
    editable: true,
  },
  {
    label: 'Status',
    fieldName: 'Status',
    editable: true,
  },
];

export default class LeadDataTable extends LightningElement {
  @track leads = [];
  @track columns = COLUMNS;
  draftValues = [];
  @api recordId;
  wiredLeadsResult;

  @wire (getListUi, {
    objectApiName: LEAD_OBJECT,
    listViewApiName: 'AllOpenLeads',
    fields: [LEAD_NAME, LEAD_EMAIL, LEAD_COMPANY, LEAD_STATUS],
  })
  wiredLeads({error, data}) {
  this.wiredLeadsResult = data;
    console.log ('***data aa raha hai*****', data);
    if (data) {
      console.log (data);
      this.leads = data.records.records.map (record => {
        return {
          Id: record.id,
          Name: record.fields.Name.value,
          Email: record.fields.Email.value,
          Company: record.fields.Company.value,
          Status: record.fields.Status.value,
        };
      });
      console.log ('leads mapped successfully', this.leads);
    } else if (error) {
      console.error ('error occurered', error);
    }
  }

  async handleSave (e) {
    this.draftValues = e.detail.draftValues;
    console.log ('----Check draft Values-----', this.draftValues);
    const inputsItems = this.draftValues.slice ().map (draft => {
      const fields = Object.assign ({}, draft);
      console.log('fields***', JSON.stringify(fields));
      ;
      return {fields};
    });

    try {
      console.log('inputsItems***', JSON.stringify(inputsItems));
      const promises = inputsItems.map(recordInput => updateRecord (recordInput))
        // console.log(recordInput)
      Promise.all (promises)
        .then (res => {
          console.log (res);
          this.dispatchEvent (
            new ShowToastEvent ({
              title: 'Success',
              message: 'Record Updated Successfully',
              variant: 'success',
            })
          );
          this.draftValues = [];  
          return refreshApex(this.wiredLeadsResult);
        })
        .catch (error => {
          console.log('error***', error);
          this.dispatchEvent (
            new ShowToastEvent ({
              title: 'Error Updating or reloading leads',
              message: error.body.message,
              variant: 'error',
            })
          );
        })
        .finally (() => {
          this.draftValues = [];
        });
    } catch (error) {
      console.error ('error occured', error);
    }
  }
}
